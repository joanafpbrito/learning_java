package cine;

import java.io.FileNotFoundException;
import java.io.IOException;

import static cine.client_library.studioRates;
import static cine.menu_library.firstMenu;

public class realDeal {
    public static void main(String[] args) throws IOException {
            firstMenu();
        }
    }

